package com.student.service;

import com.student.model.StudentRequest;

public interface StudentService {

	long registerStudent(StudentRequest studentRequest);



}
