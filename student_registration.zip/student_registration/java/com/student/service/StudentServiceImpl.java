package com.student.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.entity.Student;
import com.student.model.StudentRequest;
import com.student.repository.StudentRepository;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class StudentServiceImpl implements StudentService {
	
	Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public long registerStudent(StudentRequest studentRequest) {

		logger.info("StudentServiceImpl::: "+studentRequest.toString());
		
		Student student = new Student ();
		student.setFirstName(studentRequest.getFirstName());
		student.setLastName(studentRequest.getLastName());
		student.setEmail(studentRequest.getEmail());
		student.setMobileNo(studentRequest.getMobileNo());
		
		studentRepository.save(student);
		logger.info("StudentServiceImplID::: "+student.getId());
		return student.getId();
	}

	
	


	

}
