package com.student.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.student.model.StudentRequest;
import com.student.service.EmailService;
import com.student.service.StudentService;

import jakarta.validation.Valid;

import org.springframework.mail.SimpleMailMessage;

import org.springframework.core.env.Environment;



@RestController
@RequestMapping("/student")
public class StudentController {
	
	Logger logger = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	private StudentService studentService;

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private Environment env;

	@PostMapping("/reg_student")
	public String registerStudent( @Valid @RequestBody StudentRequest studentRequest) {
		long studentId = studentService.registerStudent(studentRequest);
				
		logger.info("Read prop file:::"+env.getProperty("spring.mail.username"));
		
		 SimpleMailMessage mailMessage = new SimpleMailMessage();
         mailMessage.setTo(studentRequest.getEmail());
         mailMessage.setSubject("Registration Successful!");
         mailMessage.setFrom(env.getProperty("spring.mail.username"));
         mailMessage.setText("Welcome !!! Your student id is : "
        +studentId);

         emailService.sendEmail(mailMessage);
		return "Student registered with student id:: " + studentId;
	}

	
}
